const bcrypt = require("bcrypt");
const functions = require("firebase-functions");
const cors = require("cors");

// The Firebase Admin SDK to access Firestore.
const admin = require("firebase-admin");
admin.initializeApp();

const saltRounds = 10;

exports.saveBoard = functions.https.onRequest(async (req, res) => {
  const options = {
    // For dev purposes. TODO: improve this
    origin: "*",
  };

  cors(options)(req, res, async () => {
    const savedState = req.body.data;

    const hashedPassword = savedState.password
      ? await bcrypt.hash(savedState.password, saltRounds)
      : null;

    // Push the board state into Firestore using the Firebase Admin SDK.
    const writeResult = await admin
      .firestore()
      .collection("saves")
      .add({
        ...savedState,
        password: hashedPassword,
      });

    // Send back a message that we've successfully saved the state
    res
      .status(200)
      .send({ data: { result: `Saved state with ID: ${writeResult.id}` } });
  });
});

exports.checkPassword = functions.https.onRequest(async (req, res) => {
  const options = {
    // For dev purposes. TODO: improve this
    origin: "*",
  };

  cors(options)(req, res, async () => {
    const { password, passwordHash } = req.body.data;

    const match = await bcrypt.compare(password, passwordHash);

    res.status(200).send({ data: { match } });
  });
});
