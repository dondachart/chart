import {
  Button,
  Checkbox,
  Drawer,
  DrawerBody,
  DrawerCloseButton,
  DrawerContent,
  DrawerFooter,
  DrawerHeader,
  DrawerOverlay,
  IconButton,
  Input,
  Text,
  useClipboard,
  useToast,
} from "@chakra-ui/react";

import { CopyIcon } from "@chakra-ui/icons";
import React from "react";
import { nanoid } from "nanoid";
import styled from "styled-components";
import useFirebaseLogic from "./useFirebaseLogic";

const SaveMenu = ({ isOpen, onClose, boxes, metadata }) => {
  const toast = useToast();
  const { saveToFirebase } = useFirebaseLogic();

  const btnRef = React.useRef();
  const [linkId, setLinkId] = React.useState(null);
  const [isProtected, setIsProtected] = React.useState(false);
  const [password, setPassword] = React.useState("");
  const [loading, setLoading] = React.useState(false);

  const fullLink = `${window.location.origin}/${linkId}`;

  const { onCopy } = useClipboard(fullLink);

  React.useEffect(() => {
    setLinkId(nanoid(11));
  }, []);

  React.useEffect(() => {
    if (!isOpen) {
      setLinkId(null);
      setIsProtected(false);
      setPassword("");
      setLoading(false);
    } else {
      setLinkId(nanoid(11));
    }
  }, [isOpen]);

  const handleSave = async () => {
    setLoading(true);
    console.log('box',boxes)
    let filter=boxes.filter((data)=>data.item.length!==0 || data.title!=='')

    console.log('filter',filter)
    const isSuccess = await saveToFirebase(
      filter,
      metadata,
      linkId,
      isProtected,
      password ? password : null
    );
    if (isSuccess) {
      onCopy();
      toast({
        description: "Link successfully created and copied!",
        status: "success",
        duration: 4000,
      });
    }

    setLoading(false);
    onClose();
  };

  return (
    <Drawer
      size="md"
      isOpen={isOpen}
      placement="right"
      onClose={onClose}
      finalFocusRef={btnRef}
    >
      <DrawerOverlay />
      <DrawerContent>
        <DrawerCloseButton />
        <DrawerHeader>Save your board & Share</DrawerHeader>

        <DrawerBody>
          <LinkContainer>
            <Text fontSize="xl">Your link:</Text>
            <LinkCopyContainer>
              <Text>{linkId ? fullLink : "Loading..."}</Text>
              <IconButton
                aria-label="Copy link"
                icon={<CopyIcon />}
                onClick={() => {
                  onCopy();
                  if (!toast.isActive(linkId)) {
                    toast({
                      description: "Link copied!",
                      status: "success",
                      duration: 3000,
                      id: linkId,
                    });
                  }
                }}
              />
            </LinkCopyContainer>
          </LinkContainer>
          <FormContainer>
            <Checkbox
              value={isProtected}
              onChange={(e) => setIsProtected(e.target.checked)}
            >
              Protect edit with a password?
            </Checkbox>
            {isProtected ? (
              <Input
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Your password..."
              />
            ) : null}
          </FormContainer>
        </DrawerBody>

        <DrawerFooter>
          <Button variant="outline" mr={3} onClick={onClose}>
            Cancel
          </Button>
          <Button
            isLoading={loading}
            loadingText="Saving"
            colorScheme="blue"
            onClick={handleSave}
          >
            Save
          </Button>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  );
};

const LinkContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  margin-bottom: 2rem;
`;

const LinkCopyContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  border-radius: 8px;
  border: 1px solid lightgrey;
  padding: 0.5rem;
  width: fit-content;
  max-width: 100%;
`;

const FormContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

export default SaveMenu;
