import {
  Button,
  ButtonGroup,
  FormControl,
  FormLabel,
  Input,
  Popover,
  PopoverArrow,
  PopoverCloseButton,
  PopoverContent,
  PopoverTrigger,
  Stack,
  useDisclosure,
} from "@chakra-ui/react";

import FocusLock from "react-focus-lock";
import { LockIcon } from "@chakra-ui/icons";
import React from "react";
import useFirebaseLogic from "./useFirebaseLogic";

const TextInput = React.forwardRef(
  ({ id, label, error, ...otherProps }, ref) => {
    return (
      <FormControl>
        <FormLabel htmlFor={id} color={error ? "red" : undefined}>
          {label}
        </FormLabel>
        <Input ref={ref} id={id} {...otherProps} isInvalid={error} />
      </FormControl>
    );
  }
);

const Form = ({ onCancel, handleSubmit, error, loading, firstFieldRef }) => {
  const [password, setPassword] = React.useState("");

  return (
    <Stack spacing={4} as="form" onSubmit={(e) => handleSubmit(e, password)}>
      <TextInput
        label="Password"
        id="password"
        type="password"
        autoComplete="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        error={error}
        ref={firstFieldRef}
      />
      <ButtonGroup d="flex" justifyContent="flex-end">
        <Button variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button
          isDisabled={password === ""}
          colorScheme="blue"
          type="submit"
          isLoading={loading}
        >
          Unlock
        </Button>
      </ButtonGroup>
    </Stack>
  );
};

const UnlockButton = ({ password: passwordHash, setPassword }) => {
  const { checkPassword } = useFirebaseLogic();
  const { onOpen, onClose, isOpen } = useDisclosure();
  const firstFieldRef = React.useRef(null);

  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState(false);

  const handleSubmit = async (e, password) => {
    e.preventDefault();
    setLoading(true);

    const isUnlocked = await checkPassword(password, passwordHash);

    if (isUnlocked) {
      setPassword(null);
      setError(false);
      setLoading(false);
      onClose();
    } else {
      setLoading(false);
      setError(true);
    }
  };

  return (
    <>
      <Popover
        isOpen={isOpen}
        initialFocusRef={firstFieldRef}
        onOpen={onOpen}
        onClose={onClose}
        placement="right"
        closeOnBlur={false}
      >
        <PopoverTrigger>
          <Button
            sx={{
              width: "200px",
            }}
            colorScheme="blue"
            leftIcon={<LockIcon />}
          >
            Unlock
          </Button>
        </PopoverTrigger>
        <PopoverContent p={5}>
          <FocusLock returnFocus persistentFocus={false}>
            <PopoverArrow />
            <PopoverCloseButton />
            <Form
              firstFieldRef={firstFieldRef}
              handleSubmit={handleSubmit}
              onCancel={onClose}
              error={error}
              loading={loading}
            />
          </FocusLock>
        </PopoverContent>
      </Popover>
    </>
  );
};

export default UnlockButton;
