import React from "react";
import { nanoid } from "nanoid";
import useFirebaseLogic from "./useFirebaseLogic";

const EMPTY_BOX = {
  width: "auto",
  height: "auto",
  x: 10,
  y: 10,
  title: "",
  item: [],
  itemValue: "",
  titleInput: true,
  itemInput: true,
  showBox: true,
};

const useBoxLogic = () => {
  const { getFirebaseData, saveToFirebase } = useFirebaseLogic();

  const [boxes, setBoxes] = React.useState([]);
  const [metadata, setMetadata] = React.useState({
    overview: "",
    showOverview: true,
    categories: "",
    showCategories: true,
  });
  const [password, setPassword] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [twitterLoading, setTwitterLoading] = React.useState(false);

  const addNewBox = () => {
    setBoxes((prevBoxes) => [...prevBoxes, { ...EMPTY_BOX, id: nanoid() }]);
  };

  const updateBoxAtIndex = (i) => (fieldName, newFieldValue) => {
    setBoxes((prevBoxes) =>
      prevBoxes.map((box, idx) =>
        idx === i
          ? {
              ...box,
              [fieldName]:
                typeof newFieldValue === "function"
                  ? newFieldValue(box[fieldName])
                  : newFieldValue,
            }
          : box
      )
    );
  };

  const shareOnTwitter = async () => {
    setTwitterLoading(true);
    const linkId = nanoid(11);
    const fullLink = `${window.location.origin}/${linkId}`;

    const isSuccess = await saveToFirebase(
      boxes,
      metadata,
      linkId,
      false,
      null
    );
    setTwitterLoading(false);

    if (isSuccess) {
      const url = `https://twitter.com/intent/tweet?text=Check%20out%20this%20board%0D%0A${fullLink}`;
      window.open(url, "_blank");
    }
  };

  React.useEffect(() => {
    const fetchBoxes = async () => {
      const savedState = await getFirebaseData(linkId);

      if (savedState.isProtected) {
        setPassword(savedState.password);
      }
      setBoxes(JSON.parse(savedState.boxes));
      setMetadata(JSON.parse(savedState.metadata));

      setLoading(false);
    };

    const linkSplit =  window.location.href.split("/")
    const linkId =linkSplit[linkSplit.length - 1];

    if (linkId) {
      fetchBoxes();
    } else {
      setLoading(false);
    }
  }, [getFirebaseData]);

  const isProtected = !!password;

  return {
    boxes,
    metadata,
    password,
    setPassword,
    isProtected,
    setMetadata,
    loading,
    addNewBox,
    updateBoxAtIndex,
    shareOnTwitter,
    twitterLoading,
  };
};

export default useBoxLogic;
