import {
  AlertDialog,
  AlertDialogBody,
  AlertDialogCloseButton,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogOverlay,
  Button,
  useDisclosure,
} from "@chakra-ui/react";

import React from "react";
import SingleComponent from "./Component";
import styled from "styled-components";

const MainComponent = ({ updateBoxAtIndex, boxes, isProtected }) => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const cancelRef = React.useRef();
  const [cardToDelete, setCardToDelete] = React.useState(null);

  React.useEffect(() => {
    if (cardToDelete !== null) {
      onOpen();
    }
  }, [cardToDelete, onOpen]);

  const handleDelete = () => {
    updateBoxAtIndex(cardToDelete)("showBox", false);
    setCardToDelete(null);
    onClose();
  };

  return (
    <Wrapper>
      {boxes.map((box, idx) => (
        <div key={box.id} style={{ margin: "0 auto" }}>
          <SingleComponent
            {...box}
            handleUpdate={updateBoxAtIndex(idx)}
            isProtected={isProtected}
            onDelete={() => setCardToDelete(idx)}
          />
        </div>
      ))}

      <AlertDialog
        motionPreset="slideInBottom"
        leastDestructiveRef={cancelRef}
        onClose={onClose}
        isOpen={isOpen}
        isCentered
      >
        <AlertDialogOverlay />

        <AlertDialogContent>
          <AlertDialogHeader>Delete card?</AlertDialogHeader>
          <AlertDialogCloseButton />
          <AlertDialogBody>
            Are you sure you want to delete this card? You won't be able to
            recover it
          </AlertDialogBody>
          <AlertDialogFooter>
            <Button ref={cancelRef} onClick={onClose}>
              No
            </Button>
            <Button colorScheme="red" ml={3} onClick={handleDelete}>
              Yes
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Wrapper>
  );
};

const Wrapper = styled.div`
  width: 100%;

  padding-top: 50px;
  height: min-content;
  display: grid;
  grid-auto-flow: dense;
  justify-content: center;

  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  grid-template-rows: auto;
  grid-gap: 25px;
`;

export default MainComponent;
