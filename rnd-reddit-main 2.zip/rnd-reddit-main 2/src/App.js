import { Button, Menu, useDisclosure } from "@chakra-ui/react";
import React, { useEffect, useRef, useState } from "react";

import { AiTwotoneEdit } from "react-icons/ai";
import { FaSave, FaTwitter } from "react-icons/fa";
import { BiPlus, BiXCircle, BiScreenshot } from "react-icons/bi";
// import { IconName } from "react-icons/ri";
import MainComponent from "./Components/MainComponent";
import SaveMenu from "./Components/SaveMenu";
import UnlockButton from "./Components/UnlockButton";
import { exportComponentAsJPEG } from "react-component-export-image";
import styled from "styled-components";
import useBoxLogic from "./Components/useBoxLogic";

const Wrapper = styled.div`
  padding: 50px;
  padding-bottom: 150px;

  .overview,
  .categories {
    border: 1px solid var(--item-color);
    border-radius: 8px;
    margin: 5px;
    color: #4a4a4a;
  }
  .overviewAndedit {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .categoryAndedit {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .overviewIcon,
  .categoryIcon {
    display: none;
  }
  .overviewAndedit:hover .overviewIcon {
    display: block;
    margin-left: 7px;
    cursor: pointer;
  }
  .categoryAndedit:hover .categoryIcon {
    display: block;
    margin-left: 7px;
    cursor: pointer;
  }
  h1 {
    color: #030104;
    padding-bottom: 18px;
  }
  h4 {
    font-weight: 500;
    line-height: 20px !important;

    color: #444444;
  }
`;

function App() {
  const {
    boxes,
    metadata,
    password,
    setPassword,
    isProtected,
    setMetadata,
    loading,
    addNewBox,
    updateBoxAtIndex,
    shareOnTwitter,
    twitterLoading,
  } = useBoxLogic();

  const [show, setShow] = useState(true);
  const [ismob, setIsmob] = useState(false);

  useEffect(() => {
    if (window.innerWidth < 760) {
      setShow(false)
      setIsmob(true)
    }
  }, [])
  const { isOpen, onOpen, onClose } = useDisclosure();

  const componentRef = useRef();

  const showOverview = (e) => {
    if (e.key === "Enter") {
      setMetadata((prev) => ({
        ...prev,
        overview: e.target.value,
        showOverview: !prev.showOverview,
      }));
    }
  };
  const showsCategory = (e) => {
    if (e.key === "Enter") {
      setMetadata((prev) => ({
        ...prev,
        categories: e.target.value,
        showCategories: !prev.showCategories,
      }));
    }
  };

  const overviewEdit = () => {
    setMetadata((prev) => ({ ...prev, showOverview: true }));
  };
  const categoryEdit = () => {
    setMetadata((prev) => ({ ...prev, showCategories: true }));
  };

  const Save = () => {
    let element = document.getElementById('menu');
    if (element) {
      element.style.opacity = 0;
      exportComponentAsJPEG(componentRef);
      element.style.opacity = 1;
    }
    else {
      alert('something went wrong');
    }

  }

  return (
    <Wrapper ref={componentRef}>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <h1 style={{fontWeight:'bold',fontSize:22}} >DONDA</h1>
        {metadata.overview && (
          <div className="overviewAndedit">
            {" "}
            <h4>{metadata.overview.toUpperCase()}</h4>{" "}
            <AiTwotoneEdit className="overviewIcon" onClick={overviewEdit} />
          </div>
        )}
        {metadata.categories && (
          <div className="categoryAndedit">
            <h4>{metadata.categories.toUpperCase()}</h4>
            <AiTwotoneEdit className="categoryIcon" onClick={categoryEdit} />
          </div>
        )}
        {metadata.showOverview && (
          <div className="overview">
            <input
              disabled={loading || isProtected}
              type="text"
              placeholder="Overview"
              onKeyUp={showOverview}
            />
          </div>
        )}
        {metadata.showCategories && (
          <div className="categories">
            <input
              disabled={loading || isProtected}
              type="text"
              placeholder="Categories"
              onKeyUp={showsCategory}
            />
          </div>
        )}
        {show ?
          <ControlsContainer id="menu">
            <Button
              disabled={loading}
              sx={{
                backgroundColor: 'black'
                //   width: "200px",
              }}
              // colorScheme="black"
              onClick={onOpen}
            >
              <FaSave style={{ color: 'white', fontSize: 18 }} />
            </Button>
            <Button
              disabled={loading}
              sx={{
                backgroundColor: 'black'
                //   width: "200px",
              }}
              // colorScheme="blue"
              onClick={shareOnTwitter}
              isLoading={twitterLoading}
              loadingText="Creating link"
            >
              {/* Share on twitter */}
              <FaTwitter style={{ color: 'white', fontSize: 18 }} />
            </Button>
            <Button
              disabled={loading}
              sx={{
                backgroundColor: 'black'
                //   width: "200px",
              }}
              // colorScheme="blue"
              onClick={Save}
            >
              <BiScreenshot style={{ color: 'white', fontSize: 18 }} />
            </Button>
            {!loading && isProtected ? (
              <UnlockButton password={password} setPassword={setPassword} />
            ) : null}
            <Button
              disabled={loading || isProtected}
              aria-label="Search database"
              sx={{ width: "fit-content", backgroundColor: 'black' }}
              onClick={() => {
                addNewBox();
                window.scrollTo(0, document.body.scrollHeight);
              }}
            >
              {/* Add */}

              <BiPlus style={{ color: 'white', fontSize: 18 }} />
            </Button>
            {ismob ?
              <Button
                disabled={loading || isProtected}
                aria-label="Search database"
                leftIcon={<BiXCircle size="25" />}
                sx={{ width: "fit-content" }}
                onClick={() => {
                  setShow(false)
                }}
              >
                Hide
              </Button>
              : null}

          </ControlsContainer>
          : <ControlsContainer style={{ top: '80vh' }}>
            <Button onClick={() => setShow(true)} className="btn-sm">Show Options</Button>
          </ControlsContainer>
        }

        <MainComponent
          updateBoxAtIndex={updateBoxAtIndex}
          boxes={boxes}
          isProtected={isProtected}
        />
      </div>

      <SaveMenu
        isOpen={isOpen}
        onClose={onClose}
        boxes={boxes}
        metadata={metadata}
      />
    </Wrapper>
  );
}

const ControlsContainer = styled.div`
  position: fixed;
  top: 1rem;
  gap: 0.5rem;
  right: 1rem;
  display: flex;
  flex-direction: column;
  padding: 1rem;
  z-index: 500;
  
`;

export default App;
