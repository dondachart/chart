import {
  collection,
  getDocs,
  getFirestore,
  query,
  where,
} from "firebase/firestore";
import { getFunctions, httpsCallable } from "firebase/functions";

import React from "react";
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC0arIBO_CebEqLJoQW1s4ZccpsrhU8Udo",
  authDomain: "donda-chart.firebaseapp.com",
  projectId: "donda-chart",
  storageBucket: "donda-chart.appspot.com",
  messagingSenderId: "620634281497",
  appId: "1:620634281497:web:b01a940ceb1dd9738e7c88"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore();
const functions = getFunctions(app);

const useFirebaseLogic = () => {
  const saveToFirebase = React.useCallback(
    async (boxes, metadata, id, isProtected = false, password = null) => {
      try {
        const saveBoard = httpsCallable(functions, "saveBoard");

        await saveBoard({
          boxes: JSON.stringify(boxes),
          metadata: JSON.stringify(metadata),
          isProtected,
          password: password,
          id,
        });

        return true;
      } catch (e) {
        console.log("Error adding document: ", e);
        return false;
      }
    },
    []
  );

  const getFirebaseData = React.useCallback(async (linkId) => {
    const q = query(collection(db, "saves"), where("id", "==", linkId));

    const queryData = await getDocs(q);

    let boxes;

    queryData.forEach((doc) => {
      boxes = doc.data();
    });

    return boxes;
  }, []);

  const checkPassword = React.useCallback(async (password, passwordHash) => {
    try {
      const checkPasswordBackend = httpsCallable(functions, "checkPassword");

      const res = await checkPasswordBackend({
        password,
        passwordHash,
      });

      return res.data.match;
    } catch (error) {
      console.log("Error adding document: ", error);
      return false;
    }
  }, []);

  return { saveToFirebase, getFirebaseData, checkPassword };
};

export default useFirebaseLogic;
