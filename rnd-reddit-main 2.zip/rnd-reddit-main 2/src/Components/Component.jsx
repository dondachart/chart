import { AiTwotoneEdit } from "react-icons/ai";
import { BiPlus } from "react-icons/bi";
import { FiMinus } from "react-icons/fi";
import { IoIosClose } from "react-icons/io";
import React,{useState,useEffect} from "react";
import { Rnd } from "react-rnd";
import styled from "styled-components";

const Wrapper = styled.div`
  margin: 0 auto !important;
  order: 0 !important;
  order: 0;
  :hover .plus {
    display: block;
  }
  :hover .close {
    display: block;
  }

  .title {
    color: var(--title-color) !important;
    font-weight: 500;
    padding-bottom: 5px;
    padding-right: 10px;
  }
  .titleAndedit,
  .itemAndedit {
    display: flex;

    align-items: center;
  }
  .titleIcon,
  .itemIcon {
    display: none;
  }
  .titleAndedit:hover .titleIcon {
    display: block;
    cursor: pointer;
  }
  .itemAndedit:hover .itemIcon {
    display: block;
    cursor: pointer;
  }
  .item {
    color: var(--item-color) !important;
    font-weight: 400;
    padding-right: 10px;
    line-height: 18px;
  }
  .input-title,
  .input-item {
    padding: 5px;
    padding-left: 15px;
    width: 90%;
  }
  .input-title {
    padding-top: 20px;
  }
  .input-item {
    position: relative;
    padding-bottom: 20px;
  }

  input {
    padding: 8px 15px;
    border: 0;
    outline: 0;
    width: 100%;
    border-radius: 6px;
    font-weight: 400;
  }
  .plus {
    position: absolute;
    top: 2%;
    right: 2%;
    display: none;
  }
  .minus {
    position: absolute;
    bottom: 30%;
    right: -15%;
    cursor: pointer;
  }
  .close {
    position: absolute;
    bottom: 2%;
    right: 2%;
    display: none;
    cursor: pointer;
  }
  @media only screen and (max-width: 600px) {
  }
  @media only screen and (max-width: 600px) {
    .title {
      color: var(--title-color) !important;
      font-weight: 500;
      padding-bottom: 5px;
    }

    .item {
      color: var(--item-color) !important;
      font-weight: 400;

      line-height: 18px;
    }
  }
`;

const style = {
  width: "30%",
  border: "solid 1px #ddd",
  background: "#000",
  borderRadius: "20px",
  padding: "15px",
  position: "relative",
};

const SingleComponent = ({
  width,
  height,
  x,
  y,
  title,
  item,
  itemValue,
  titleInput,
  itemInput,
  showBox,
  handleUpdate,
  isProtected,
  onDelete,
}) => {

 


  useEffect(()=>{
    if(window.location.pathname!=='/' && title){
      handleUpdate("itemInput", false)
    //  handleUpdate("titleInput", false)
    }
   
  },[])


  const showTitle = (e) => {
    if (e.key === "Enter") {
      handleUpdate("title", e.target.value);
      handleUpdate("titleInput", (prev) => !prev);
    }
  };

  const showItem = (e) => {
    if (e.key === "Enter") {
      handleUpdate("item", (prev) => [...prev, e.target.value]);
      handleUpdate("itemValue", "");
    }
  };
  const titleEdit = () => {
    if (isProtected) return;

    handleUpdate("titleInput", (prev) => !prev);
  };
  const itemEdit = (i) => {
    if (isProtected) return;

    const newItem = item.filter((el, index) => index !== i);
    handleUpdate("itemInput", (prev) => true);

    handleUpdate("item", newItem);
  };



  return (
    showBox && (
      <Wrapper className="container" style={{ margin: "0 auto" }}>
        <Rnd
          cancel="#yourId"
          style={style}
          enableResizing={!isProtected}
          disableDragging={isProtected}
          size={{ width: width, height: height }}
          position={{ x: x, y: y }}
          minWidth={180}
          minHeight={130}
          onDragStop={(e, d) => {
            handleUpdate("x", d.x);
            handleUpdate("y", d.y);
          }}
          onResizeStop={(e, direction, ref, delta, position) => {
            handleUpdate("width", ref.style.width);
            handleUpdate("height", ref.style.height);
          }}
        >
          {title && (
            <div className="titleAndedit">
              {" "}
              <h3 className="title">{title.toUpperCase()}</h3>
              <AiTwotoneEdit
                color="#fff"
                className="titleIcon"
                onClick={titleEdit}
              />
            </div>
          )}
          {item &&
            item.map((data, i) => (
              <div className="itemAndedit" key={i}>
                <h4 className="item">{data.toUpperCase()}</h4>
                <AiTwotoneEdit
                  color="#fff"
                  className="itemIcon"
                  onClick={() => itemEdit(i)}
                />
              </div>
            ))}
          {titleInput && (
            <div className="input-title">
              <input
                disabled={isProtected}
                type="text"
                placeholder="Your title"
                onKeyUp={showTitle}
                onMouseDown={(e) => e.stopPropagation()}
              />
            </div>
          )}
          {itemInput && (
            <div className="input-item">
              <input
                disabled={isProtected}
                type="text"
                value={itemValue}
                placeholder="new item"
                onChange={(e) => handleUpdate("itemValue", e.target.value)}
                onKeyUp={showItem}
                onMouseDown={(e) => e.stopPropagation()}
                className="thisItem"
              />
              <button
                className="minus"
                disabled={isProtected}
                onClick={() => handleUpdate("itemInput", false)}
              >
                <FiMinus color="#fff" size="25" />
              </button>
            </div>
          )}

          <button
            disabled={isProtected}
            className="plus"
            onClick={() => handleUpdate("itemInput", true)}
          >
            <BiPlus color="#fff" size="25" />
          </button>
          <button disabled={isProtected} className="close" onClick={onDelete}>
            <IoIosClose color="#fff" size="25" />
          </button>
        </Rnd>
      </Wrapper>
    )
  );
};
export default SingleComponent;
